from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request,'index.html')


def analyze(request):
    s1=request.GET.get('s1',);
    r1 = request.GET.get('r1', );
    s2 = request.GET.get('s2', 'default');
    r2 = request.GET.get('r2', 'default');
    s3 = request.GET.get('s3', 'default');
    r3 = request.GET.get('r3', 'default');
    s4 = request.GET.get('s4', 'default');
    r4 = request.GET.get('r4', 'default');
    s5 = request.GET.get('s5', 'default');
    r5 = request.GET.get('r5', 'default');
    params={"s1":s1,"r1":r1,"s2":s2,"r2":r2,"s3":s3,"r3":r3,"s4":s4,"r4":r4,"s5":s5,"r5":r5};
    return render(request,'analyze.html',params);
